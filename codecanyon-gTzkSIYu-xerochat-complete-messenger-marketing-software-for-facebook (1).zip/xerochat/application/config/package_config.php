<?php 
$config['backup_mode'] = '0';
